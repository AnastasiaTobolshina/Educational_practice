<?php

class Menu
{
    public $mas;

    public function __construct($mas){
        $this -> mas = $mas;
    }

    public function createMenu($name, $echo = ''){
        $a = 'class=colorlib-active';
        $echo .= "<aside id='colorlib-aside' role='complementary' class='js-fullheight'><nav id='colorlib-main-menu' role='navigation'> <ul>";
        foreach($this->mas as $key=>$val){

            if(!is_array($val)){
                $echo .= "<li><a " . ($val == $name ? $a : '') . "href=" . $val . ">" . $key . "</a></li>";
                //'<li class="colorlib-active"><a href="'. $val . '">' . $key . '</a></li>';
            }else{
                foreach($val as $k => $v) {
                    if(!(array_key_last($val) == $k)) {
                        $echo .= "<li><a " . ($v == $name ? $a : '') . "href=" . $v . ">" . $k . "</a>/";
                    } else {
                        $echo .= "<a " . ($v == $name ? $a : '') . "href=" . $v . ">" . $k . "</a></li>";
                    }
                }
            }
        }
        $echo .= "</ul></nav></aside>";

        return $echo;
    }
        
}