<?php
class MySql extends mysqli {

    public $db = [];
    public $isConnected = false;

    public function __construct($host, $username, $password, $database) {

        parent::__construct($host, $username, $password, $database);

        if (is_null($this->connect_error)) {
            $this->isConnected = false;
        } else {
            $this->isConnected = true;
        }
    }

    public function pompt($sql) {
        $result = $this->query($sql);
        $rows = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
        }
        return $rows;
    }

    public function isUnique($tableName, $field, $value) {
        $result = false;
        $sql = "SELECT COUNT(*) as count FROM $tableName WHERE $field = '$value'";

        if ($q = $this->query($sql)) {
        $row = $q->fetch_assoc();
        $result = $row['count'] == 0;
        }
        return $result;

    }

}