<?php
class Request {
    public $isPost = false;
    public $isGet = false;

    public function __construct() {
        $this->isPost = ($_SERVER["REQUEST_METHOD"] === "POST");
        $this->isGet = ($_SERVER["REQUEST_METHOD"] === "GET");
    }

    public function cleanInput($input) {
        return trim(strip_tags($input));
    }

    public function cleanArray($array) {
            if (is_array($array)) {
                foreach ($array as $key => $value) {
                    $array[$key] = $this->cleanInput($value);
            } 
        }
        return $array;
    }

    public function post($key = null) {
        if (is_null($key)) {
            $post = $this->cleanArray($_POST);
        }else {
            if(isset($_POST[$key])) {
                $post = $this -> cleanInput($_POST[$key]);
            }else{
                $post = null;
            }
        }
        return $post;
    }

    public function get($key = null) {
        if (is_null($key)) {
            $get = $this->cleanArray($_GET);
        }else {
            if(isset($_GET[$key])) {
                $get = $this -> cleanInput($_GET[$key]);
            }else{
                $get = null;
            }
        }
        return $get;
    }

    public function getHost() {
        return $_SERVER["HTTP_HOST"];
    }

    public function getToken() {
  if(isset($_GET['token'])) {
    return $_GET['token'];
  } else {
    return null;
        }
    }
}

?>