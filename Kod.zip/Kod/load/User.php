<?php
class User {

    public $name;
    public $surname;
    public $patronymic;
    public $login;
    public $email;
    public $password;
    public $password_repeat;

    public $token ;
    public $validatName;
    public $validatPatronymic;
    public $validatSurname;
    public $validatLogin;
    public $validatEmail;
    public $validatPassword;
    public $validatPassword_repeat;
    public $validatRules;

    public $adminLogin = 'admin';
    public $adminPassword = '09031993';

    public $isGuest = true;
    public $isAdmin = false;

    public $request;
    public $mySql;

    public function __construct($request, $mySql) {
        $this->request = $request;
        $this->mySql = $mySql;
    }
    public function load($mas) {
        foreach ($mas as $key => $value) {
            if (property_exists($this, $key)) {
                $this->$key = $value;
            }
        }
          $this->isGuest = false;
        if ($this->isAdmin()) {
            $this->isAdmin = true;
        }
    }
   
    public function validateRegister()
    {
        if (empty($this->surname) || empty($this->name) || empty($this->login) || empty($this->email)){
            if (empty($this->surname)){
                $this->validatSurname = 'Поле "Фамилия" обязательно для заполнения';
            } if (empty($this->name)){
                $this->validatName = 'Поле "Имя" обязательно для заполнения';
            } if (empty($this->login)){
                $this->validatLogin = 'Поле "Логин" обязательно для заполнения';
            } if (empty($this->email)){
                $this->validatEmail = 'Поле "Email" обязательно для заполненияя';
            } else if (!strpos($this->email, '@')){
                $this->validatEmail = 'Некорректно введен email. Знак "@" отсутствует';
            } else if ($this->email[0] == '@'){
                $this->validatEmail = 'Некорректно введен email. Перед знаком "@" ничего нет';
            } else if ($this->email[strlen($this->email) - 1] == '@'){
                $this->validatEmail = 'Некорректно введен email. После знака "@" ничего нет';
            }; if (empty ($this -> password)) {
                $this -> validatPassword = 'Поле "Пароль" обязательно для заполнения';
            } else if (($this -> password) < 6){
                $this -> validatPassword = 'Пароль должен содержать не менее 6 символов';
            }; if (empty ($this -> password_repeat)){
                $this -> validatPassword_repeat = 'Поле "Подтверждение пароля" обязательно для заполнения';
            } else if (($this -> password_repeat) < 6){
                $this -> validatPassword_repeat = 'Пароль должен содержать не менее 6 символов';
            } else if (($this -> password_repeat) != ($this -> password)){ 
                $this -> validatPassword_repeat = 'Пароли не совпадают';
            }

        foreach(get_object_vars($this) as $key=>$val) {
            if (strpos($key , 'validat') !== false){
                return false;
            }
            return true;
        }   
    }
}
   public function save() {
        $result = false;
        $sql = "INSERT INTO user (name, surname, patrnymic , login, email, password, roules_id) 
        VALUES ('$this->name', '$this->surname', '$this->patronymic', '$this->login', '$this->email', '$this->password', 2)";
        if ($this->mySql->query($sql)) {
            $result = true;
        }
        return $result;
    }

    
    public function validateLogin(){
        if(empty($this->login)){
            $this-> validatLogin = 'Введите логин';
        }

        if(empty($this->password)){
            $this->validatPassword = 'Введите пароль';
        }

        if(!$this->mySql->query("SELECT user_id FROM user WHERE password = '$this->password' AND login = '$this->login'")){
            $this->validatPassword = 'Логин или пароль не верны';
        }
        foreach(get_object_vars($this) as $key=>$val) {
            if (is_string($val)) {
                if (strpos($key , 'validat') !== false){
                    return false;
                }
            }
        }
    }
    public function login(){
        if($mas = $this->mySql->pompt("SELECT * FROM user WHERE login = '$this->login' AND password = '$this->password'"));
            if(empty($mas)){
            $this->validatPassword = 'Введен неверный пароль';
            return false;
        }
            $this->load($mas[0]);
            $this->isGuest = false;
            if($this->isAdmin()){
                $this->isAdmin = true;
            }
            $this->token = $this->token();
            
            if($this->mySql->query("UPDATE user SET token = '$this->token' WHERE login = '$this->login'"));
                return true;
            }
        

    function token(){ 
        $token = '';
        $symbols = 'abcdefjhijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        while(strlen($token) < 14){
            $token .=  str_shuffle($symbols)[rand(0, strlen($symbols) - 1)];
        }
        return $token;
    }

    public function identity($id = null){
        if($id === null){
            $this->load($this->mySql->pompt("SELECT * FROM {$this->name} WHERE token = '{$_GET["token"]}'")[0]);
        } else {
            $this->load($this->mySql->pompt("SELECT * FROM {$this->name} WHERE validatName = '$id'")[0]);
        }
    }

    public function isAdmin(){
        if($this->login == $this->adminLogin && $this->password == $this->adminPassword
        ){
            $result = true;
        } else{
            $result = false;
        }
        return $result;
    }

    public function logout(){
        if(!$this->isGuest){
            $this->mySql->myQuery("UPDATE $this->tableName SET token = NULL WHERE token = '$this->token'");
            $this->token = NULL;
            $this->isGuest = true;
            return true;
        } else {
            return false;
        }
    }
}






?>
