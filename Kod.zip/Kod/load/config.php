<?php

$menu = [
    "Главная" => "index.php",
    "Блоги" => "posts.php",
    "Пользователи" => "users.php",
    "О нас" => "about.php",
    "Вход" => "login.php",
    "Регистрация" => "register.php",
    "Выход" => "#"
];
$mas = [
        'host' => '127.0.0.1',
        'user' => 'root',
        'password' => '',
        'database' => 'Practica1'
    ];

?>