<?php

require 'load/autoload.php';
require 'load/config.php';

$menuClass = new Menu($menu);
$req = new Request();
$db = new MySql($mas['host'], $mas['user'], $mas['password'], $mas['database']);
$user = new User($req, $db);
?>