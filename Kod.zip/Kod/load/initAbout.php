<?php

require('load/init.php');

?>