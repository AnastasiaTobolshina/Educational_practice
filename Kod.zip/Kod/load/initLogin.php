<?php

require('load/init.php');
if($user->request->isPost){
    $mas = $user->request->post();
    $user->load($mas);
    $user->validateLogin();

    if($user->login()){
        header("location: index.php ?$user->token");

    }
}
?>


<!-- ?$user->token -->