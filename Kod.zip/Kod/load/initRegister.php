<?php
require_once 'load/init.php';


if($user->request->isPost){
    $qqq = $user->request->post();
    $user->load($qqq);

    if (!$user->validateRegister()) {
        if ($user->save()){
            header('location:index.php');
        }
    }
 
}


?>




