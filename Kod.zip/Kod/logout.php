<?
require_once 'load/init.php';
$user->logout();
$myResponse->redirect('index.php', []);